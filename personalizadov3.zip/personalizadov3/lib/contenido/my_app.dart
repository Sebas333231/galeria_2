import 'package:flutter/foundation.dart';
import 'package:flutter_speed_dial/flutter_speed_dial.dart';
import 'package:flutter/material.dart';

class MyApp extends StatelessWidget {
  const MyApp({super.key});


  static const showGrid = true; //Set to false to show ListView

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Galeria Personalizada',
      home: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.blueGrey,
          title: const Text('Galeria Personalizada'),
        ),
        body: Center(child: showGrid ? _buildGrid() : _buildList()),
        drawer: Drawer(
          backgroundColor: Colors.white,
          child: ListView(
            children: <Widget>[
              UserAccountsDrawerHeader(
                decoration: const BoxDecoration(
                  image: DecorationImage(
                      image: AssetImage('../image/pic8.jpg'),
                      fit: BoxFit.cover,
                  ),
                ),
                  accountName: const Text(
                    'Sebastian',
                    style: TextStyle(
                      fontSize: 20,
                    ),
                  ), 
                  accountEmail: const Text(
                   'sebastian@gmail.com',
                   style: TextStyle(
                     fontSize: 15,
                   ), 
                  ),
                currentAccountPicture: CircleAvatar(
                  backgroundColor: Colors.black,
                  child: ClipOval(
                    child: Image.asset('../image/epa.png',
                      width: 90,
                      height: 90,
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
              ),
              //DrawerHeader(
                //decoration: const BoxDecoration(
                  //color: Colors.black,
                //),
                //child: Container(
                  //decoration: const BoxDecoration(
                    //image: DecorationImage(
                      //image: AssetImage('../image/epa.png'),
                      //fit: BoxFit.cover,
                    //),
                  //),
                //),
              //),
              //Column(
                //children: const [
                  //Text(
                    //'Sena CBA',
                    //style: TextStyle(
                      //color: Colors.black,
                      //fontSize: 25,
                    //),
                  //),
                  //Text(
                    //'Bienvenidos',
                    //style: TextStyle(
                      //color: Colors.black,
                      //fontSize: 25,
                    //),
                  //),
                //],
              //),
              Column(
                children: const [
                  ListTile(
                    title: Text("Inicio"),
                    leading: Icon(Icons.home), iconColor: Colors.blue,
                  ),
                  Divider(
                    height: 0.2,
                  ),
                  ListTile(
                    title: Text("Tiendas"),
                    leading: Icon(Icons.storefront), iconColor: Colors.blue,
                  ),
                  ListTile(
                    title: Text("Promociones"),
                    leading: Icon(Icons.shopping_cart), iconColor: Colors.blue,
                  ),
                  ListTile(
                    title: Text("Categorias"),
                    leading: Icon(Icons.category), iconColor: Colors.blue,
                  ),
                  Divider(
                    height: 0.2,
                  ),
                  ListTile(
                    title: Text("email"),
                    leading: Icon(Icons.mail), iconColor: Colors.blue,
                  ),
                  ListTile(
                    title: Text("Soporte"),
                    leading: Icon(Icons.contact_phone_sharp), iconColor: Colors.blue,
                  ),
                ],
              )
            ],
          ),
        ),
        floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
        floatingActionButton: SpeedDial(
          animatedIcon: AnimatedIcons.view_list,
          backgroundColor: Colors.black,
          overlayOpacity: 0.4,
          overlayColor: Colors.black,
          children: [
            SpeedDialChild(
              label: 'Mail',
              backgroundColor: Colors.white,
              child: const Icon(Icons.mail),
            ),
            SpeedDialChild(
                child: const Icon(Icons.copy),
                backgroundColor: Colors.white,
                label: 'copiar'
            ),
            SpeedDialChild(
                child: const Icon(Icons.facebook),
                backgroundColor: Colors.white,
                label: 'Facebook'
            ),
            SpeedDialChild(
                child: const Icon(Icons.whatsapp),
                backgroundColor: Colors.white,
                label: 'Whatsapp'
            ),
          ],
        ),
        bottomNavigationBar: BottomAppBar(
          shape: const CircularNotchedRectangle(), color: Colors.blueGrey,
          notchMargin: 10,
          child: Row(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              IconButton(icon: const Icon(Icons.menu), iconSize: 30, onPressed: () {},),
              IconButton(icon: const Icon(Icons.search), iconSize: 30, onPressed: () {},)
            ],
          ),
        ),
      ),
    );
  }


  // #inicia_construcion_con_Gridview
  Widget _buildGrid() => GridView.extent(
      maxCrossAxisExtent: 300,
      padding: const EdgeInsets.all(4),
      mainAxisSpacing: 4,
      crossAxisSpacing: 4,
      children: _buildGridTileList(30)); // GridView.extent

  //Las imagenes estan almacenadas con nombres pic0.jpg.....
  // El constructor List.generate() provee un camino sencillo para crear
  // una lista de objetos que tienen un molde de nombre predecible

  List<Container> _buildGridTileList(int count) =>
      List.generate(
          count, (i) => Container(child: Image.asset('../image/pic$i.jpg'))
      );
  // ## Fin_construccion_con_GridView
  Widget _buildList() {
    return ListView(
      children: [
        _tile('CineArts at the Empire', '85 W Portal Ave', Icons.theaters),
        _tile('The Castro Theater', '429 Castro St', Icons.theaters),
        _tile('Alamo Draft-house Cinema', '2550 Mission St', Icons.theaters),
        _tile('Roxie Theater', '3117 16th St', Icons.theaters),
        _tile('United Artists Stones town Twin', '501 Buckingham Way',
            Icons.theaters),
        _tile('AMC Metreon 16', '135 4th St #3000', Icons.theaters),
        const Divider(),
        _tile('K\'s Kitchen', '757 Monterrey Blud', Icons.theaters),
        _tile('Emmy\'s Restaurant', '1923 Ocean Ave', Icons.theaters),
        _tile('Chai Thai Restaurant', '272 Claremont Blued', Icons.theaters),
        _tile('La Cia', '291 30th St', Icons.theaters),
      ],
    );
  }

  ListTile _tile(String title, String subtitle, IconData icon) {
    return ListTile(
      title: Text(title,
          style: const TextStyle(
            fontWeight: FontWeight.w500,
            fontSize: 20,
          )),
      subtitle: Text(subtitle),
      leading: Icon(
        icon,
        color: Colors.blue[500],
      ),
    );
  }
}
